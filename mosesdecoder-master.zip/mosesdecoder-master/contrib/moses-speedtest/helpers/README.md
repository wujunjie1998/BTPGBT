###Helpers

This is a python script that basically gives you the equivalent of:
```echo 3 > /proc/sys/vm/drop_caches```
You need to set it up so it is executed with root access without needing a password so that the tests can be automated.